# Spring Web Services (SOAP) using Spring Boot example

- `http://localhost:8091/soapWS` - request xml is under `src/main/resource/user-request.xml`
